// Avoid `console` errors in browsers that lack a console.
(function() {
    var method;
    var noop = function() {};
    var methods = [
        'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error',
        'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log',
        'markTimeline', 'profile', 'profileEnd', 'table', 'time', 'timeEnd',
        'timeline', 'timelineEnd', 'timeStamp', 'trace', 'warn'
    ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];

        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());

// Place any jQuery/helper plugins in here.
//slider active
jQuery(document).ready(function() {
    jQuery('.slider-active').owlCarousel({
        items: 1,
        nav: true,
        navText: ['back', 'next'],
        loop: true,
        autoplay: true,
        autoplaySpeed: 1500,
        animateOut: 'fadeOut',
        animateIn: 'flipInX',

    });
    // product slider active
    jQuery('.product-active').owlCarousel({
        items: 4,
        nav: true,
        navText: ['back', 'next'],
        loop: false,
        autoplay: true,
        animateOut: 'fadeOut',
        animateIn: 'flipInX',

        margin: 30,
        responsive: {
            0: {
                items: 1,

            },
            420: {
                items: 2,

            },
            600: {
                items: 3,

            },
            1000: {
                items: 4,

            }
        }

    });
    // brand slider active
    jQuery('.brand-active').owlCarousel({
        items: 6,
        nav: false,
        autoplay: true,
        animateOut: 'fadeOut',
        animateIn: 'flipInX',
        margin: 10,
        responsive: {
            0: {
                items: 2,

            },
            480: {
                items: 4,

            },
            850: {
                items: 6,

            }

        }

    });
});