var body = document.querySelector('.body-section');
var logo = document.querySelector('.logo');
var headerRight = document.querySelector('.header-right');
var mainToggler = document.querySelector('.menu-bar-toggler');
var mainMenu = document.querySelector('.main-menu');
var overlay = document.querySelector('.overlay');

// var menuStatus = true;
// dropdown containers
var dropdownContainers = document.querySelectorAll('.dd-container>i')
var dropdownLinks = document.querySelectorAll('.dd-container a')
var dropdownMenus = document.querySelectorAll('.dp-menu')
for (let i = 0; i < dropdownContainers.length; i++) {
    dropdownContainers[i].addEventListener('click', function() {
        dropdownMenus[i].classList.toggle('mbl-dropdown-open')
        dropdownLinks[i].setAttribute('style', 'pointer-event:none')

        this.classList.toggle('mbl-dropdown-active')
    })
}

function removeDropdown() {
    for (let b = 0; b < dropdownMenus.length; b++) {
        dropdownMenus[b].classList.remove('mbl-dropdown-open')

    }
    for (let c = 0; c < dropdownContainers.length; c++) {
        dropdownContainers[c].classList.remove('mbl-dropdown-active')
    }

}

mainToggler.addEventListener('click', function() {
        mainMenu.classList.toggle('left-0');
        mainToggler.classList.toggle('menu-toggler-bar');
        overlay.classList.toggle('overlay-add')
        removeDropdown();
        body.classList.toggle('ml-25rem')
        logo.classList.toggle('d-none')
        headerRight.classList.toggle('d-none')

    })
    //jquery

$(document).ready(function() {
        jQuery('.overlay').click(function() {
            jQuery('.main-menu').addClass('left--23rem');
            jQuery('.menu-bar-toggler').removeClass('menu-toggler-position')
            jQuery('.overlay').removeClass('overlay-add')
            jQuery('.overlay').addClass('overlay-remove')
            jQuery('.main-menu').removeClass('left-0')
            removeDropdown()
            body.classList.remove('ml-25rem')
            logo.classList.remove('d-none')
            mainToggler.classList.remove('menu-toggler-bar');
            headerRight.classList.remove('d-none')

        })
        $(document).on("click", function(event) {
            var $searchFieldTrigger = $("#search-field-container");
            var $cartTrigger = $(".cart-container");
            var $menuTrigger = $(".main-menu ul li");

            if ($searchFieldTrigger !== event.target && !$searchFieldTrigger.has(event.target).length) {
                $("#search-field").slideUp();
            }
            if ($cartTrigger !== event.target && !$cartTrigger.has(event.target).length) {
                $(".cart").slideUp();
            }
        })

        $("#search-btn").click(function() {
            $('#search-field').slideToggle(300)
        })
        jQuery('.cart-dlt-btn--1').click(function() {
            jQuery('.cart-item--1').addClass('d-none')
        })
        jQuery('.cart-dlt-btn--2').click(function() {
            jQuery('.cart-item--2').addClass('d-none')
        })
        jQuery('.cart-dlt-btn--3').click(function() {
            jQuery('.cart-item--3').addClass('d-none')
        })
        jQuery('.cart-btn').click(function() {
            jQuery('.cart').slideToggle(400)
        })
        jQuery('.header-right-toggler').click(function() {
                jQuery('.header-right >ul').slideToggle()
            })
            //goggle map
        function basicmap() {
            // Basic options for a simple Google Map
            // For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
            var mapOptions = {
                // How zoomed in you want the map to start at (always required)
                zoom: 11,
                scrollwheel: false,
                // The latitude and longitude to center the map (always required)
                center: new google.maps.LatLng(22.700411, 90.374992), // New York
                // This is where you would paste any style found on Snazzy Maps.
                styles: [{
                        "featureType": "all",
                        "elementType": "labels.text.fill",
                        "stylers": [{
                                "saturation": 36
                            },
                            {
                                "color": "#000000"
                            },
                            {
                                "lightness": 40
                            }
                        ]
                    },
                    {
                        "featureType": "all",
                        "elementType": "labels.text.stroke",
                        "stylers": [{
                                "visibility": "on"
                            },
                            {
                                "color": "#000000"
                            },
                            {
                                "lightness": 16
                            }
                        ]
                    },
                    {
                        "featureType": "all",
                        "elementType": "labels.icon",
                        "stylers": [{
                            "visibility": "off"
                        }]
                    },
                    {
                        "featureType": "administrative",
                        "elementType": "geometry.fill",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 20
                            }
                        ]
                    },
                    {
                        "featureType": "administrative",
                        "elementType": "geometry.stroke",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 17
                            },
                            {
                                "weight": 1.2
                            }
                        ]
                    },
                    {
                        "featureType": "landscape",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 20
                            }
                        ]
                    },
                    {
                        "featureType": "poi",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 21
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway",
                        "elementType": "geometry.fill",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 17
                            }
                        ]
                    },
                    {
                        "featureType": "road.highway",
                        "elementType": "geometry.stroke",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 29
                            },
                            {
                                "weight": 0.2
                            }
                        ]
                    },
                    {
                        "featureType": "road.arterial",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 18
                            }
                        ]
                    },
                    {
                        "featureType": "road.local",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 16
                            }
                        ]
                    },
                    {
                        "featureType": "transit",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 19
                            }
                        ]
                    },
                    {
                        "featureType": "water",
                        "elementType": "geometry",
                        "stylers": [{
                                "color": "#000000"
                            },
                            {
                                "lightness": 17
                            }
                        ]
                    }
                ]
            };
            // Get the HTML DOM element that will contain your map 
            // We are using a div with id="map" seen below in the <body>
            var mapElement = document.getElementById('contact-map');

            // Create the Google Map using our element and options defined above
            var map = new google.maps.Map(mapElement, mapOptions);

            // Let's also add a marker while we're at it
            var marker = new google.maps.Marker({
                position: new google.maps.LatLng(22.700411, 90.374992),
                map: map,
                title: 'Cryptox'
            });
        }
        if ($('#contact-map').length != 0) {
            google.maps.event.addDomListener(window, 'load', basicmap);
        }

    })
    //shop page